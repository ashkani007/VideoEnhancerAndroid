package com.oai.videoenhancer;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.effect.Contrast;
import androidx.media3.effect.HslAdjustment;
import androidx.media3.effect.LanczosResample;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.TransformationRequest;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.VideoEncoderSettings;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 1001;

    private Uri selectedUri;
    private Uri finalMediaUri;
    private File workingOutputFile;
    private Transformer transformer;

    private Button selectButton;
    private Button startButton;
    private Button openOutputButton;
    private Spinner presetSpinner;
    private Spinner codecSpinner;
    private CheckBox enhanceCheck;
    private TextView fileInfo;
    private TextView statusText;
    private ProgressBar progressBar;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ProgressHolder progressHolder = new ProgressHolder();

    private final Runnable progressRunnable = new Runnable() {
        @Override
        public void run() {
            if (transformer == null) return;
            try {
                int state = transformer.getProgress(progressHolder);
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    progressBar.setProgress(progressHolder.progress);
                    statusText.setText("در حال پردازش… " + progressHolder.progress + "%");
                }
                handler.postDelayed(this, 500);
            } catch (Exception ignored) {
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.oai.videoenhancer.R.layout.activity_main);

        selectButton = findViewById(R.id.selectButton);
        startButton = findViewById(R.id.startButton);
        openOutputButton = findViewById(R.id.openOutputButton);
        presetSpinner = findViewById(R.id.presetSpinner);
        codecSpinner = findViewById(R.id.codecSpinner);
        enhanceCheck = findViewById(R.id.enhanceCheck);
        fileInfo = findViewById(R.id.fileInfo);
        statusText = findViewById(R.id.statusText);
        progressBar = findViewById(R.id.progressBar);

        String[] presets = {
                "1080p High Quality",
                "1440p Ultra",
                "4K Maximum Quality"
        };
        presetSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, presets));
        presetSpinner.setSelection(2);

        String[] codecs = {
                "Auto — HEVC/H.265 ترجیحی",
                "H.264 — سازگاری بیشتر"
        };
        codecSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, codecs));

        selectButton.setOnClickListener(v -> pickVideo());
        startButton.setOnClickListener(v -> startEnhancement());
        openOutputButton.setOnClickListener(v -> openOutput());
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        startActivityForResult(intent, PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                        selectedUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (Exception ignored) {
            }
            finalMediaUri = null;
            openOutputButton.setVisibility(View.GONE);
            startButton.setEnabled(true);
            showVideoInfo(selectedUri);
        }
    }

    private void showVideoInfo(Uri uri) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, uri);
            String w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            long ms = duration == null ? 0 : Long.parseLong(duration);
            fileInfo.setText(String.format(Locale.getDefault(),
                    "ویدئو انتخاب شد — %sx%s — %.1f ثانیه",
                    w == null ? "?" : w,
                    h == null ? "?" : h,
                    ms / 1000.0));
            statusText.setText("آماده برای پردازش");
        } catch (Exception e) {
            fileInfo.setText("ویدئو انتخاب شد");
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    private void startEnhancement() {
        if (selectedUri == null) {
            Toast.makeText(this, "ابتدا یک ویدئو انتخاب کن", Toast.LENGTH_SHORT).show();
            return;
        }

        startButton.setEnabled(false);
        selectButton.setEnabled(false);
        openOutputButton.setVisibility(View.GONE);
        progressBar.setProgress(0);
        statusText.setText("آماده‌سازی پردازش…");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        int preset = presetSpinner.getSelectedItemPosition();
        int firstDimension;
        int secondDimension;
        int bitrate;
        if (preset == 0) {
            firstDimension = 1920;
            secondDimension = 1080;
            bitrate = 18_000_000;
        } else if (preset == 1) {
            firstDimension = 2560;
            secondDimension = 1440;
            bitrate = 35_000_000;
        } else {
            firstDimension = 3840;
            secondDimension = 2160;
            bitrate = 60_000_000;
        }

        boolean autoHevc = codecSpinner.getSelectedItemPosition() == 0;
        String videoMime = autoHevc && hasEncoder(MimeTypes.VIDEO_H265)
                ? MimeTypes.VIDEO_H265
                : MimeTypes.VIDEO_H264;

        List<Effect> videoEffects = new ArrayList<>();
        videoEffects.add(LanczosResample.scaleToFitWithFlexibleOrientation(firstDimension, secondDimension));
        if (enhanceCheck.isChecked()) {
            videoEffects.add(new Contrast(0.07f));
            videoEffects.add(new HslAdjustment.Builder()
                    .adjustSaturation(4.0f)
                    .adjustLightness(0.8f)
                    .build());
        }

        EditedMediaItem editedMediaItem = new EditedMediaItem.Builder(MediaItem.fromUri(selectedUri))
                .setEffects(new Effects(Collections.emptyList(), videoEffects))
                .build();

        VideoEncoderSettings videoSettings = new VideoEncoderSettings.Builder()
                .setBitrate(bitrate)
                .build();

        DefaultEncoderFactory encoderFactory = new DefaultEncoderFactory.Builder(this)
                .setEnableFallback(true)
                .setRequestedVideoEncoderSettings(videoSettings)
                .build();

        File dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        if (dir == null) dir = getFilesDir();
        workingOutputFile = new File(dir, "enhanced_" + System.currentTimeMillis() + ".mp4");

        transformer = new Transformer.Builder(this)
                .setVideoMimeType(videoMime)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoderFactory)
                .addListener(new Transformer.Listener() {
                    @Override
                    public void onCompleted(Composition composition, ExportResult result) {
                        handler.removeCallbacks(progressRunnable);
                        progressBar.setProgress(100);
                        statusText.setText("پردازش تمام شد؛ در حال ذخیره در گالری…");
                        saveToGallery(workingOutputFile);
                    }

                    @Override
                    public void onError(Composition composition, ExportResult result, ExportException exception) {
                        handler.removeCallbacks(progressRunnable);
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        startButton.setEnabled(true);
                        selectButton.setEnabled(true);
                        statusText.setText("خطا: " + safeMessage(exception));
                    }

                    @Override
                    public void onFallbackApplied(
                            Composition composition,
                            TransformationRequest originalTransformationRequest,
                            TransformationRequest fallbackTransformationRequest) {
                        statusText.setText("گوشی بعضی تنظیمات را پشتیبانی نکرد؛ نزدیک‌ترین حالت سازگار انتخاب شد…");
                    }
                })
                .build();

        try {
            transformer.start(editedMediaItem, workingOutputFile.getAbsolutePath());
            handler.post(progressRunnable);
        } catch (Exception e) {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            startButton.setEnabled(true);
            selectButton.setEnabled(true);
            statusText.setText("شروع پردازش ناموفق بود: " + safeMessage(e));
        }
    }

    private boolean hasEncoder(String mimeType) {
        try {
            MediaCodecList list = new MediaCodecList(MediaCodecList.ALL_CODECS);
            for (MediaCodecInfo info : list.getCodecInfos()) {
                if (!info.isEncoder()) continue;
                for (String type : info.getSupportedTypes()) {
                    if (type.equalsIgnoreCase(mimeType)) return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void saveToGallery(File source) {
        if (source == null || !source.exists()) {
            finishWithError("فایل خروجی پیدا نشد");
            return;
        }

        new Thread(() -> {
            Uri uri = null;
            try {
                ContentResolver resolver = getContentResolver();
                String displayName = "VideoEnhancer_" + System.currentTimeMillis() + ".mp4";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
                values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
                values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoEnhancer");
                values.put(MediaStore.Video.Media.IS_PENDING, 1);

                uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("MediaStore insert failed");

                try (InputStream in = new FileInputStream(source);
                     OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Output stream unavailable");
                    byte[] buffer = new byte[1024 * 1024];
                    int n;
                    while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                    out.flush();
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.Video.Media.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
                finalMediaUri = uri;
                source.delete();

                runOnUiThread(() -> {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    startButton.setEnabled(true);
                    selectButton.setEnabled(true);
                    statusText.setText("تمام شد ✓ ویدئو در Movies/VideoEnhancer ذخیره شد");
                    openOutputButton.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "ویدئو در گالری ذخیره شد", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                if (uri != null) {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                }
                String msg = safeMessage(e);
                runOnUiThread(() -> finishWithError("ذخیره در گالری ناموفق بود: " + msg));
            }
        }).start();
    }

    private void finishWithError(String message) {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startButton.setEnabled(true);
        selectButton.setEnabled(true);
        statusText.setText(message);
    }

    private void openOutput() {
        if (finalMediaUri == null) return;
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(finalMediaUri, "video/mp4");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "برنامه‌ای برای باز کردن ویدئو پیدا نشد", Toast.LENGTH_SHORT).show();
        }
    }

    private String safeMessage(Throwable t) {
        String msg = t.getMessage();
        return (msg == null || msg.trim().isEmpty()) ? t.getClass().getSimpleName() : msg;
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(progressRunnable);
        if (transformer != null && isFinishing()) {
            try { transformer.cancel(); } catch (Exception ignored) {}
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }
}

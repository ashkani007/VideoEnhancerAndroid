plugins {
    id("com.android.application")
}

android {
    namespace = "com.oai.videoenhancer"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.oai.videoenhancer"
        minSdk = 29
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.media3:media3-transformer:1.11.0")
    implementation("androidx.media3:media3-effect:1.11.0")
    implementation("androidx.media3:media3-common:1.11.0")
}

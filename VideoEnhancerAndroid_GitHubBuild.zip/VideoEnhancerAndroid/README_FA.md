# Video Enhancer Pro — Android

نسخهٔ Native اندروید برای افزایش کیفیت ویدئو روی خود گوشی.

## قابلیت‌ها
- انتخاب ویدئو از Gallery / Files
- خروجی 1080p، 1440p یا 4K
- Upscale با Lanczos GPU
- H.265/HEVC در صورت پشتیبانی گوشی، با fallback به H.264
- بیت‌ریت بالا برای جلوگیری از افت کیفیت مجدد
- بهبود ملایم Saturation / Lightness / Contrast
- نمایش درصد پیشرفت
- ذخیرهٔ خروجی در `Movies/VideoEnhancer`
- بدون آپلود ویدئو روی اینترنت

## ساخت APK
1. Android Studio Quail 4 یا جدیدتر را نصب کن.
2. پوشهٔ `VideoEnhancerAndroid` را با Open باز کن.
3. صبر کن Gradle Sync کامل شود.
4. از منوی Build گزینه `Build APK(s)` را بزن.
5. APK معمولاً در این مسیر ساخته می‌شود:
   `app/build/outputs/apk/debug/app-debug.apk`

## نیازمندی‌های پروژه
- Android Gradle Plugin 9.4.0
- compileSdk 37
- minSdk 29 (Android 10+)
- Jetpack Media3 1.11.0

## دربارهٔ «بالاترین کیفیت ممکن»
این نسخه از upscale باکیفیت و انکود سخت‌افزاری با بیت‌ریت بالا استفاده می‌کند. اما AI Super Resolution واقعی، که فریم‌ها را با مدل عصبی بازسازی کند، هنوز در این نسخه نیست. اضافه کردن آن نیازمند یک مدل مناسب موبایل (مثلاً TFLite/ONNX) و طراحی pipeline فریم‌به‌فریم است و مصرف GPU/NPU و باتری را بسیار بالا می‌برد.

## ساخت APK فقط با گوشی و GitHub
اگر کامپیوتر نداری، این پروژه شامل workflow آماده GitHub Actions است:

1. در github.com یک Repository جدید بساز.
2. همه فایل‌های این پروژه را در Repository آپلود کن (پوشه مخفی `.github` هم باید آپلود شود).
3. به تب Actions برو و workflow با نام `Build Android APK` را باز کن.
4. `Run workflow` را بزن.
5. بعد از پایان Build، در همان صفحه بخش Artifacts را باز کن و `VideoEnhancerPro-debug-apk` را دانلود کن.
6. ZIP artifact را باز کن و `app-debug.apk` را روی گوشی نصب کن.
7. اگر Android اجازه نصب نداد، برای مرورگر/Files گزینه `Install unknown apps` را موقتاً فعال کن.

این APK از نوع Debug است و برای تست شخصی مناسب است.
